package com.pkt.clock

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.time.ZoneId
import java.time.ZonedDateTime

val PKT: ZoneId = ZoneId.of("Asia/Karachi")

data class Alarm(
    var id: Int, var h: Int, var m: Int, var days: Int = 0, var label: String = "",
    var tone: String = "Crisp Ring", var vibrate: Boolean = true, var interval: Int = 5,
    var count: Int = 3, var on: Boolean = true, var left: Int = 0, var next: Long = 0L
)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)
    fun load(c: Context): MutableList<Alarm> {
        val out = mutableListOf<Alarm>()
        try {
            val a = JSONArray(sp(c).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Alarm(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getInt("days"), o.getString("label"),
                    o.getString("tone"), o.getBoolean("vibrate"), o.getInt("interval"), o.getInt("count"),
                    o.getBoolean("on"), o.getInt("left"), o.getLong("next")))
            }
        } catch (e: Exception) { }
        return out
    }
    fun save(c: Context, l: List<Alarm>) {
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("id", it.id).put("h", it.h).put("m", it.m).put("days", it.days).put("label", it.label)
                .put("tone", it.tone).put("vibrate", it.vibrate).put("interval", it.interval).put("count", it.count)
                .put("on", it.on).put("left", it.left).put("next", it.next))
        }
        sp(c).edit().putString("list", a.toString()).apply()
    }
    fun get(c: Context, id: Int): Alarm? = load(c).firstOrNull { it.id == id }
    fun put(c: Context, a: Alarm) {
        val l = load(c); val i = l.indexOfFirst { it.id == a.id }
        if (i >= 0) l[i] = a else l.add(a)
        save(c, l)
    }
    fun remove(c: Context, id: Int) = save(c, load(c).filter { it.id != id })
}

object Sched {
    fun nextOcc(a: Alarm): Long {
        val now = ZonedDateTime.now(PKT)
        for (i in 0..7) {
            val t = now.toLocalDate().plusDays(i.toLong()).atTime(a.h, a.m).atZone(PKT)
            if (t.isAfter(now) && (a.days == 0 || ((a.days shr (t.dayOfWeek.value % 7)) and 1) == 1))
                return t.toInstant().toEpochMilli()
        }
        return 0L
    }
    private fun pi(c: Context, a: Alarm): PendingIntent = PendingIntent.getBroadcast(
        c, a.id, Intent(c, AlarmReceiver::class.java).putExtra("id", a.id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, a: Alarm) {
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(a.next, show), pi(c, a))
    }
    fun cancel(c: Context, a: Alarm) { c.getSystemService(AlarmManager::class.java).cancel(pi(c, a)) }
    fun arm(c: Context, a: Alarm) { a.on = true; a.left = a.count; a.next = nextOcc(a); Store.put(c, a); set(c, a) }
    fun off(c: Context, a: Alarm) { a.on = false; a.next = 0L; Store.put(c, a); cancel(c, a) }
    fun finish(c: Context, a: Alarm) { if (a.days != 0) arm(c, a) else off(c, a) }
    fun rescheduleAll(c: Context) {
        Store.load(c).forEach {
            if (it.on) {
                if (it.next > System.currentTimeMillis()) set(c, it) else finish(c, it)
            }
        }
    }
}
