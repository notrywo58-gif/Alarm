package com.pkt.clock

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.media.*
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

object Tones {
    class Note(val f: Double, val t: Double, val d: Double, val v: Double)
    class Tone(val wave: Int, val notes: List<Note>)
    private val raw = linkedMapOf(
        "Crisp Ring" to "0|880,0,0.25,0.4;880,0.35,0.25,0.4",
        "Soft Chime" to "0|660,0,1.1,0.4;990,0.35,0.9,0.25",
        "Digital" to "2|1000,0,0.12,0.3;1000,0.18,0.12,0.3;1000,0.36,0.12,0.3",
        "Morning Bell" to "0|523,0,1,0.35;659,0.3,1,0.3;784,0.6,1.2,0.3",
        "Gentle Rise" to "1|392,0,0.5,0.35;494,0.25,0.5,0.35;587,0.5,0.5,0.35;784,0.75,0.9,0.35",
        "Marimba" to "1|523,0,0.3,0.5;659,0.2,0.3,0.5;523,0.4,0.3,0.5;784,0.6,0.5,0.5",
        "Pulse" to "0|440,0,0.12,0.5;440,0.22,0.12,0.5;440,0.44,0.12,0.5;440,0.66,0.12,0.5",
        "Sonar" to "0|600,0,1.6,0.5",
        "Bright Duo" to "1|784,0,0.35,0.45;988,0.3,0.6,0.45",
        "Water Drop" to "0|1200,0,0.15,0.4;900,0.2,0.25,0.4;1200,0.7,0.15,0.3;900,0.9,0.25,0.3",
        "Retro Arcade" to "2|523,0,0.1,0.25;659,0.1,0.1,0.25;784,0.2,0.1,0.25;1047,0.3,0.25,0.25",
        "Calm Pad" to "0|262,0,1.8,0.25;330,0,1.8,0.25;392,0,1.8,0.25",
        "Kitchen Timer" to "1|1500,0,0.06,0.3;1500,0.1,0.06,0.3;1500,0.2,0.06,0.3;1500,0.3,0.06,0.3;1500,0.4,0.06,0.3;1500,0.5,0.06,0.3"
    )
    val names: List<String> = raw.keys.toList()
    private fun parse(s: String): Tone {
        val p = s.split("|")
        return Tone(p[0].toInt(), p[1].split(";").map { n ->
            val v = n.split(",").map { it.toDouble() }; Note(v[0], v[1], v[2], v[3])
        })
    }
    fun pcm(name: String): ShortArray {
        val t = parse(raw[name] ?: raw.values.first())
        val sr = 44100
        val len = ((t.notes.maxOf { it.t + it.d } + 0.5) * sr).toInt()
        val buf = FloatArray(len)
        for (n in t.notes) {
            val s0 = (n.t * sr).toInt(); val c = (n.d * sr).toInt()
            for (i in 0 until c) {
                val idx = s0 + i
                if (idx >= len) break
                val ph = (n.f * i / sr) % 1.0
                val w = when (t.wave) { 0 -> sin(2 * PI * ph); 1 -> 4 * abs(ph - 0.5) - 1; else -> if (ph < 0.5) 1.0 else -1.0 }
                val x = i.toDouble() / c
                val env = min(1.0, i / (0.01 * sr)) * (1 - x) * (1 - x)
                buf[idx] += (w * env * n.v * 1.3).toFloat()
            }
        }
        return ShortArray(len) { (buf[it].coerceIn(-1f, 1f) * 32767).toInt().toShort() }
    }
}

object Beep {
    private var track: AudioTrack? = null
    fun start(name: String, loop: Boolean) {
        stop()
        val pcm = Tones.pcm(name)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        tr.write(pcm, 0, pcm.size)
        if (loop) tr.setLoopPoints(0, pcm.size, -1)
        tr.play(); track = tr
    }
    fun stop() {
        track?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        track = null
    }
}

fun timeText(a: Alarm): String = LocalTime.of(a.h, a.m).format(DateTimeFormatter.ofPattern("h:mm a"))

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = Store.get(c, i.getIntExtra("id", -1)) ?: return
        if (!a.on) return
        a.left--
        if (a.left > 0 && a.interval > 0) {
            a.next = System.currentTimeMillis() + a.interval * 60000L
            Store.put(c, a); Sched.set(c, a)
        } else Sched.finish(c, a)
        ContextCompat.startForegroundService(c, Intent(c, RingService::class.java).putExtra("id", a.id))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Sched.rescheduleAll(c) }
}

class RingService : Service() {
    private val h = Handler(Looper.getMainLooper())
    override fun onBind(i: Intent?): IBinder? = null

    private fun end() {
        h.removeCallbacksAndMessages(null)
        Beep.stop()
        getSystemService(Vibrator::class.java).cancel()
        sendBroadcast(Intent("com.pkt.clock.DISMISS").setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val id = i?.getIntExtra("id", -1) ?: -1
        when (i?.action) {
            "STOP" -> { Store.get(this, id)?.let { Sched.finish(this, it) }; end(); return START_NOT_STICKY }
            "LATER" -> {
                Store.get(this, id)?.let {
                    if (!(it.on && it.left > 0 && it.interval > 0)) {
                        it.on = true; it.left = 1
                        it.next = System.currentTimeMillis() + (if (it.interval > 0) it.interval else 5) * 60000L
                        Store.put(this, it); Sched.set(this, it)
                    }
                }
                end(); return START_NOT_STICKY
            }
        }
        val a = Store.get(this, id) ?: run { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ring", "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false)
        })
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val full = PendingIntent.getActivity(this, id, Intent(this, RingActivity::class.java).putExtra("id", id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fl)
        fun act(name: String, rc: Int) = PendingIntent.getService(this, id * 10 + rc,
            Intent(this, RingService::class.java).setAction(name).putExtra("id", id), fl)
        val n = NotificationCompat.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (a.label.isEmpty()) "Alarm" else a.label)
            .setContentText(timeText(a))
            .setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX)
            .setFullScreenIntent(full, true).setOngoing(true)
            .addAction(0, "Remind later", act("LATER", 1)).addAction(0, "Stop", act("STOP", 2)).build()
        ServiceCompat.startForeground(this, id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        Beep.start(a.tone, true)
        if (a.vibrate) getSystemService(Vibrator::class.java)
            .vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ end() }, 60000)
        return START_NOT_STICKY
    }

    override fun onDestroy() { Beep.stop(); super.onDestroy() }
}

class RingActivity : AppCompatActivity() {
    private val dismiss = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { finish() } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getIntExtra("id", -1)
        val a = Store.get(this, id)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#D9552B")); setPadding(48, 48, 48, 48)
        }
        fun tv(t: String, s: Float) = TextView(this).apply { text = t; textSize = s; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        col.addView(tv("Alarm", 18f))
        col.addView(tv(if (a != null) timeText(a) else "", 64f))
        col.addView(tv(a?.label ?: "", 22f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 64, 0, 0) }
        fun btn(t: String, act: String) = Button(this).apply {
            text = t
            setOnClickListener {
                startService(Intent(this@RingActivity, RingService::class.java).setAction(act).putExtra("id", id))
                finish()
            }
        }
        row.addView(btn("Remind later", "LATER")); row.addView(btn("Stop", "STOP"))
        col.addView(row)
        setContentView(col)
        ContextCompat.registerReceiver(this, dismiss, IntentFilter("com.pkt.clock.DISMISS"), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onDestroy() { unregisterReceiver(dismiss); super.onDestroy() }
}
