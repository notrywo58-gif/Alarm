package com.pkt.clock

import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.time.Instant
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var clock: TextView
    private val h = Handler(Looper.getMainLooper())
    private val acc = Color.parseColor("#7C9CF0")
    private val dn = arrayOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    private val fmt = DateTimeFormatter.ofPattern("h:mm:ss a  ·  EEE, d MMM  ·  'PKT'")
    private val tick = object : Runnable {
        override fun run() { clock.text = ZonedDateTime.now(PKT).format(fmt); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(56), dp(24), dp(130)) }
        col.addView(TextView(this).apply { text = "Alarm"; textSize = 36f })
        clock = TextView(this).apply { textSize = 15f; alpha = 0.7f; setPadding(0, dp(4), 0, dp(16)) }
        col.addView(clock)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list)
        sv.addView(col); root.addView(sv)
        val fab = FloatingActionButton(this).apply { setImageResource(android.R.drawable.ic_input_add) }
        root.addView(fab, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(36) })
        fab.setOnClickListener { edit(null) }
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
    }

    override fun onResume() { super.onResume(); refresh(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); Beep.stop() }

    private fun whenText(a: Alarm): String {
        if (a.days != 0) return if (a.days == 127) "Every day" else (0..6).filter { ((a.days shr it) and 1) == 1 }.joinToString(", ") { dn[it] }
        val n = if (a.next > 0) a.next else Sched.nextOcc(a)
        val d = Instant.ofEpochMilli(n).atZone(PKT).toLocalDate()
        val k = ChronoUnit.DAYS.between(LocalDate.now(PKT), d)
        return if (k < 1L) "Today" else if (k == 1L) "Tomorrow" else dn[d.dayOfWeek.value % 7]
    }

    private fun refresh() {
        list.removeAllViews()
        val all = Store.load(this).sortedBy { it.h * 60 + it.m }
        if (all.isEmpty()) list.addView(TextView(this).apply { text = "No alarms yet. Tap + to add one."; alpha = 0.6f; setPadding(0, dp(40), 0, 0); gravity = Gravity.CENTER })
        for (a in all) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(14)); alpha = if (a.on) 1f else 0.5f }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(TextView(this).apply { text = timeText(a).lowercase(); textSize = 38f; typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL) })
            val extra = if (a.interval > 0 && a.count > 1) " · ${a.count}× every ${a.interval} min" else ""
            val lab = if (a.label.isEmpty()) "" else a.label + " · "
            left.addView(TextView(this).apply { text = lab + whenText(a) + extra; textSize = 14f; alpha = 0.7f })
            row.addView(left, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(MaterialSwitch(this).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, c -> if (c) Sched.arm(this@MainActivity, a) else Sched.off(this@MainActivity, a); refresh() }
            })
            row.setOnClickListener { edit(a) }
            list.addView(row)
        }
    }

    private fun edit(a: Alarm?) {
        val x = a?.copy() ?: Alarm(0, 8, 0)
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8)) }
        fun lbl(t: String) = TextView(this).apply { text = t; textSize = 13f; alpha = 0.7f; setPadding(0, dp(14), 0, dp(4)) }
        val timeBtn = Button(this)
        fun upd() { timeBtn.text = timeText(x) + "  (PKT)" }
        upd()
        timeBtn.setOnClickListener { TimePickerDialog(this, { _, hh, mm -> x.h = hh; x.m = mm; upd() }, x.h, x.m, false).show() }
        v.addView(timeBtn)
        v.addView(lbl("Repeat (none selected = only once)"))
        val dayRow = LinearLayout(this)
        for (i in 0..6) {
            val tv = TextView(this).apply { text = "SMTWTFS"[i].toString(); gravity = Gravity.CENTER }
            fun paint() {
                val on = ((x.days shr i) and 1) == 1
                tv.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) acc else Color.TRANSPARENT); setStroke(2, acc) }
                tv.setTextColor(if (on) Color.BLACK else acc)
            }
            paint()
            tv.setOnClickListener { x.days = x.days xor (1 shl i); paint() }
            dayRow.addView(tv, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(6) })
        }
        v.addView(dayRow)
        v.addView(lbl("Alarm sound"))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Tones.names)
        sp.setSelection(Tones.names.indexOf(x.tone).coerceAtLeast(0))
        var first = true
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, w: View?, pos: Int, id: Long) {
                x.tone = Tones.names[pos]
                if (first) first = false else Beep.start(x.tone, false)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        v.addView(sp)
        v.addView(MaterialSwitch(this).apply { text = "Vibrate"; isChecked = x.vibrate; setOnCheckedChangeListener { _, c -> x.vibrate = c } })
        v.addView(lbl("Label"))
        val label = EditText(this).apply { setText(x.label); hint = "Label"; setSingleLine() }
        v.addView(label)
        v.addView(lbl("Remind later every (minutes)"))
        val interval = EditText(this).apply { setText(x.interval.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        v.addView(interval)
        v.addView(lbl("Ring up to (times)"))
        val count = EditText(this).apply { setText(x.count.toString()); inputType = InputType.TYPE_CLASS_NUMBER }
        v.addView(count)
        val b = AlertDialog.Builder(this).setTitle("Set alarm").setView(ScrollView(this).apply { addView(v) })
            .setPositiveButton("Save") { _, _ ->
                x.label = label.text.toString().trim()
                x.interval = interval.text.toString().toIntOrNull()?.coerceIn(0, 720) ?: 5
                x.count = count.text.toString().toIntOrNull()?.coerceIn(1, 30) ?: 3
                if (x.interval == 0) x.count = 1
                if (x.id == 0) x.id = (System.currentTimeMillis() / 1000).toInt()
                Sched.arm(this, x); refresh()
            }
            .setNegativeButton("Cancel", null)
        if (a != null) b.setNeutralButton("Delete") { _, _ -> Sched.cancel(this, a); Store.remove(this, a.id); refresh() }
        b.setOnDismissListener { Beep.stop() }
        b.show()
    }
}
